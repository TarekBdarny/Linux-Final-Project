Name : Tarek Bdarny
id : 325347086
Presinting alone.

In this program I used try and expect to make sure if any errors accures during the runtime 
of the program , and display custom errors for the user to make sure he can fix the problem